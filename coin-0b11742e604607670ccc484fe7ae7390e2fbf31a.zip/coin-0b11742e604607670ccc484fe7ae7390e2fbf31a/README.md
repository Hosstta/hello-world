# coin
Bitcoin by Satoshi Nakamoto with Node Incentivisation and Dynamic Fibonacci block size growth.
